<?php
    require_once('auth.php');
?>
<?php
//checking connection and connecting to a database
require_once('connection/config.php');
//Connect to mysql server
    $link = @mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);
    if(!$link) {
        die('Failed to connect to server: ' . mysql_error());
    }
    
    //Select database
    $db = mysql_select_db(DB_DATABASE);
    if(!$db) {
        die("Unable to select database");
    }
    
//define default values for flag_0
$flag_0 = 0;
    
//get member_id from session
$member_id = $_SESSION['SESS_MEMBER_ID'];

//selecting particular records from the food_details and cart_details tables. Return an error if there are no records in the tables
$result=mysql_query("SELECT food_name,food_description,food_price,food_photo,cart_id,quantity_value,total,flag,category_name FROM food_details,cart_details,categories,quantities WHERE cart_details.member_id='$member_id' AND cart_details.flag='$flag_0' AND cart_details.food_id=food_details.food_id AND food_details.food_category=categories.category_id AND cart_details.quantity_id=quantities.quantity_id")
or die("A problem has occured ... \n" . "Our team is working on it at the moment ... \n" . "Please check back after few hours."); 
?>
<?php
    if(isset($_POST['Submit'])){
        //Function to sanitize values received from the form. Prevents SQL injection
        function clean($str) {
            $str = @trim($str);
            if(get_magic_quotes_gpc()) {
                $str = stripslashes($str);
            }
            return mysql_real_escape_string($str);
        }
        //get category id
        $id = clean($_POST['category']);
        
        //selecting all records from the food_details table based on category id. Return an error if there are no records in the table
        $result=mysql_query("SELECT * FROM food_details WHERE food_category='$id'")
        or die("A problem has occured ... \n" . "Our team is working on it at the moment ... \n" . "Please check back after few hours."); 
    }
?>
<?php
    //retrieving quantities from the quantities table
    $quantities=mysql_query("SELECT * FROM quantities")
    or die("Something is wrong ... \n" . mysql_error()); 
?>
<?php
    //retrieving cart ids from the cart_details table
    //define a default value for flag_0
    $flag_0 = 0;
    $items=mysql_query("SELECT * FROM cart_details WHERE member_id='$member_id' AND flag='$flag_0'")
    or die("Something is wrong ... \n" . mysql_error());
    //get the number of rows
    $num_items = mysql_num_rows($items);
?>
<?php
    //retrieving all rows from the messages table
    $messages=mysql_query("SELECT * FROM messages")
    or die("Something is wrong ... \n" . mysql_error()); 
    //get the number of rows
    $num_messages = mysql_num_rows($messages);
?>
<?php
    //retrive a currency from the currencies table
    //define a default value for flag_1
    $flag_1 = 1;
    $currencies=mysql_query("SELECT * FROM currencies WHERE flag='$flag_1'")
    or die("A problem has occured ... \n" . "Our team is working on it at the moment ... \n" . "Please check back after few hours."); 
?>
<!DOCTYPE html>
<html>
<head>
<title>Restaurant</title>
<meta charset="utf-8">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/jpg" href="image/a.jpg">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/nivo-lightbox.css">
    <link rel="stylesheet" type="text/css" href="css/default.css">
    <link rel="stylesheet" type="text/css" href="css/hover-min.css">
    <link rel="stylesheet" href="css/prettyPhoto.css" type="text/css" media="screen" charset="utf-8" />
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" type="text/css" href="font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <!-- DataTables CSS -->
    <link href="css/dataTables.bootstrap.css" type="text/css" rel="stylesheet">
    <!-- DataTables Responsive CSS -->
    <link href="css/dataTables.responsive.css" type="text/css" rel="stylesheet">
  <script type="text/javascript" src="js/jquery_1_11_2.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <script src="js/jquery.prettyPhoto.js" type="text/javascript" charset="utf-8"></script>
  <script language="JavaScript" src="validation/user.js"></script>
<!-- <link href="stylesheets/user_styles.css" rel="stylesheet" type="text/css"> -->
  <style type="text/css">
  .listh{
  text-align: center;
  color: #669999;
  font-family: Comic Sans MS;
  }
  </style>
</head>
<body>
<div class="banner">
  <div class="container" >
    <div class="row">
      <div class="col-sm-12" style="margin: 5px 0px;"> 
        <a href="index.php"><img src="image/restaurant_logo.png" class="img-responsive"></a>
      </div>
    </div>
    </div>
<div> 
<nav class="navbar navbar-inverse"  data-spy="affix" data-offset-top="197">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="index.php">RESTAURANT</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="index.php">Home</a></li>
        <li><a href="foodzone.php" class="hvr-underline-from-left">Food Zone</a></li>
        <li><a href="specialdeals.php" class="hvr-underline-from-left">Special Deals</a></li>
        <li class="active"><a href="member-index.php" class="hvr-underline-from-left">My Account</a></li>
        <li><a href="contactus.php" class="hvr-underline-from-left">Contact Us</a></li>
        <li><a href="aboutus.php" class="hvr-underline-from-left">AboutUS</a></li>
        <li><a href="team.php" class="hvr-underline-from-left">OurTeam</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li class="hvr-float-shadow">
          <a href="https://www.facebook.com/Restaurant-OS-551156428337035/" target="blank" data-toggle="tooltip" data-placement="top" title="Facebook">
            <img src="image/facebook_logo.png" style="width: 32px;height: 32px;" class="img-responsive">
          </a>
        </li>
        <li class="hvr-float-shadow">
          <a href="#" data-toggle="tooltip" data-placement="top" title="Twitter">
            <img src="image/twitter.png" style="width: 32px;height: 32px;" class="img-responsive">
          </a>
        </li>
        <li class="hvr-float-shadow">
          <a href="#" data-toggle="tooltip" data-placement="top" title="Google plus">
            <img src="image/google_plus.png" style="width: 32px;height: 32px;" class="img-responsive">
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>
</div>
</div>

<div class="content">
<div class="container">
  <div class="row" >
    <div class="col-sm-12">
      <div id="myCarousel" class="carousel slide" data-ride="carousel" style="position: relative; margin-top: -60px;">
    <!-- Indicators -->
          <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
          </ol>

          <!-- Wrapper for slides -->
          <div class="carousel-inner" role="listbox">
            <div class="item active">
              <img src="image/food/1.jpg" class="img-responsive">
            </div>

            <div class="item">
              <img src="image/food/2.jpg" class="img-responsive">
            </div>
          
            <div class="item">
              <img src="image/food/3.jpg" class="img-responsive">
            </div>
          </div>

          <!-- Left and right controls -->
          <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>
        </div>
    </div>
  </div>
  <div class="row">
    <div class="col-sm-12 thumbnail">
      <ul class="nav nav-tabs" role="tablist">
        <li><a href="member-index.php">Home</a></li>
        <li class="active"><a href="cart.php">Cart[<?php echo $num_items;?>]</a></li>
        <li><a href="inbox.php">Inbox[<?php echo $num_messages;?>]</a></li>
        <li><a href="tables.php">Tables</a></li>
        <li><a href="partyhalls.php">Party-Halls</a></il> 
        <li><a href="ratings.php">Rate Us</a></li>
        <li><a href="member-profile.php">My Profile</a></li>    
        <li><a href="logout.php">Logout</a></li> 
      </ul>
    </div>
  </div>
  <div class="row">
    <div class="col-sm-12 wow fadeInDown" data-wow-delay="0.1s">
      <h1 style=" text-align: center; margin-top: 7px; margin-left: 0;font-weight:bold; font-family: Forte;"><a href="foodzone.php">Continue Shopping!</a></h1>
    </div>
  </div>
  <div class="row" >
    <div class="col-sm-12 wow fadeInUp"  data-wow-delay="0.1s">
      <div class="panel panel-warning" style="border-radius: 15px;">
        <div class="panel-heading" style="border-top-right-radius: 15px;border-top-left-radius: 15px;">
          <div class="row">
            <form name="quantityForm" id="quantityForm" method="post" action="update-quantity.php" onsubmit="return updateQuantity(this)">
            <div class="col-md-2 col-md-offset-3 wow bounceInLeft"  data-wow-delay="0.3s"">
              <select class="form-control" name="item" id="item">
                <option value="select">select Item ID
                  <?php 
                            //loop through cart_details table rows
                    while ($row=mysql_fetch_array($items)){
                    echo "<option value=$row[cart_id]>$row[cart_id]"; 
                    }
                  ?>
                </option>  
              </select>
            </div>
            <div class="col-md-2 wow bounceIn">
              <select class="form-control" name="quantity" id="quantity">
                <option value="select">select Quantity
                  <?php
                    //loop through quantities table rows
                    while ($row=mysql_fetch_assoc($quantities)){
                    echo "<option value=$row[quantity_id]>$row[quantity_value]"; 
                    }
                  ?>
                </option>  
              </select>
            </div>
            <div class="col-md-2 wow bounceInRight"  data-wow-delay="0.3s">
              <button class="btn btn-info btn-block" type="submit" name="Submit" value="Change Quantity">Change</button> 
            </div>
            </form>
          </div>
        </div>

      <div class="panel-body" style="background-color: #ffffe6; margin-bottom: -20px;">
        <div class="row">
          <div class="col-sm-12 table-responsive">
            <table class="table table-hover">
              <thead>
                <tr>
                  <th width="10%" style="text-align: center;">Item ID</th>
                  <th width="10%" style="text-align: center;">Food Photo</th>
                  <th width="15%" style="text-align: center;">Food Name</th>
                  <th width="15%" style="text-align: center;">Food Description</th>
                  <th width="10%" style="text-align: center;">Category</th>
                  <th width="10%" style="text-align: center;">Food Price</th>
                  <th width="10%" style="text-align: center;">Quantity</th>
                  <th width="10%" style="text-align: center;">Total Cost</th>
                  <th width="10%" style="text-align: center;">Action(s)</th>
                </tr>
              </thead>
              <tbody>
                <?php
                  //loop through all table rows
                  $symbol=mysql_fetch_assoc($currencies); //gets active currency
                  while ($row=mysql_fetch_array($result)){                   
                    echo ' <tr align="center" class="wow fadeInDown"  data-wow-delay="0.3s">';
                    echo '<td><h4 class="listh">' . $row['cart_id'].'</h4></td>';
                    echo '<td><a rel="prettyPhoto" href=images/'. $row['food_photo']. ' alt="click to view full image"><img class="hvr-float-shadow img-responsive" src=images/'. $row['food_photo'].' ></a></td>';
                    echo '<td><h4 class="listh">' . $row['food_name'].'</h4></td>';
                    echo '<td><h4 class="listh">' . $row['food_description'].'</h4></td>';
                    echo '<td><h4 class="listh">' . $row['category_name'].'</h4></td>';
                    echo '<td><h4 class="listh">' . $symbol['currency_symbol']. $row['food_price'].'</h4></td>';
                    echo '<td><h4 class="listh">' . $row['quantity_value']."</td>";
                    echo '<td><h4 class="listh">' . $symbol['currency_symbol']. $row['total'].'</h4></td>'; 
                    echo '<td><a class="btn btn-success btn-block hvr-float-shadow" href="order-exec.php?id=' . $row['cart_id']. '">Please Order</a></td>';
                    echo '</tr>';
                    
                  }
                  mysql_free_result($result);
                  mysql_close($link);
                ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      </div>
    </div>
  </div>

</div>
</div>
<footer class="parallax-section" id="footer4">
  <div class="container" >
    <div class="row">
      <div class="col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.6s">
        <h4 class="heading-f">Contact Info:</h4>
        <div class="ph">
          <h6 class="heading-f1"><i class="fa fa-phone"></i>Phone:</h6>
          <h6 class="heading-f1"><i>+855 (0)15 5555 54 </i></h6>
          <h6 class="heading-f1"><i>+855 (0)12 5555 54</i></h6>
        </div>

        <div class="em">
          <h6 class="heading-f"><i class="fa fa-envelope"></i>Email:</h6>
          <h6 class="heading-f">restaurant_os@gmail.com</h6>
        </div>

        <div class="address">
          <h4 class="heading-f"><i class="fa fa-map-marker"></i> Our Location:</h4>
          <h6 class="heading-f"><i>No.136, Preah Sisowath Blvd, Phnom Penh, Cambodia</i></h6>
        </div>
      </div>
      
      <div class="col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.6s">
        <h4 class="heading-f">Open Hours</h4>
          <h6 class="heading-f"><i>Sunday <span>7:30 AM - 10:00 PM</span></i></h6>
          <h6 class="heading-f"><i>Mon-Fri <span>6:00 AM - 10:00 PM</span></i></h6>
          <h6 class="heading-f"><i>Saturday <span>6:30 AM - 10:00 PM</span></i></h6>
      </div>
      <div class="col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.6s">
        <h4 class="heading-f">Information</h4>
        <h6 class="heading-f"><i>Delivery Service</i></h6>
        <h6 class="heading-f"><i>News and Events</i></h6>
        <ul class="social-icon"; type="none">
          <li>
            <a href="https://www.facebook.com/Restaurant-OS-551156428337035/" target="blank" class="fa fa-facebook wow bounceIn" data-wow-delay="0.3s"></a>
          </li>
          <li><a href="#" class="fa fa-twitter wow bounceIn" data-wow-delay="0.6s"></a></li>
          <li><a href="#" class="fa fa-instagram wow bounceIn" data-wow-delay="0.9s"></a></li>
          <li><a href="#" class="fa fa-youtube wow bounceIn" data-wow-delay="0.11s"></a></li>
          <li><a href="#" class="fa fa-google  wow bounceIn" data-wow-delay="0.11s"></a></li>
        </ul><br>
        <a href="admin/index.php" target="_blank"><h6 class="heading-f"><i>Administrator</i></h6></a>
        <h6 class="heading-f"><i>© 2010-2017 Restaurant OS. All rights reserved.</i></h6>
      </div>
    </div>
  </div>
</footer>
<script type="text/javascript" charset="utf-8">
$(document).ready(function(){
  $("a[rel^='prettyPhoto']").prettyPhoto();
});
</script>
 <script src="js/wow.min.js"></script>
<script>
    new WOW().init();
</script>
</body>
</html>