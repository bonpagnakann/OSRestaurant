<!DOCTYPE html>
<html>
<head>
<title>Restaurant</title>
<meta charset="utf-8">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/jpg" href="image/a.jpg">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/nivo-lightbox.css">
    <link rel="stylesheet" type="text/css" href="css/default.css">
    <link rel="stylesheet" type="text/css" href="css/hover-min.css">
    <link rel="stylesheet" href="css/prettyPhoto.css" type="text/css" media="screen" charset="utf-8" />
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" type="text/css" href="font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
  <script type="text/javascript" src="js/jquery_1_11_2.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <script src="js/jquery.prettyPhoto.js" type="text/javascript" charset="utf-8"></script>
  <script language="JavaScript" src="validation/user.js"></script>
<!-- <link href="stylesheets/user_styles.css" rel="stylesheet" type="text/css"> -->
</head>
<body>
<div class="banner">
  <div class="container" >
    <div class="row">
      <div class="col-sm-12" style="margin: 5px 0px;"> 
        <a href="index.php"><img src="image/restaurant_logo.png" class="img-responsive"></a>
      </div>
    </div>
    </div>
<div> 
<nav class="navbar navbar-inverse"  data-spy="affix" data-offset-top="197">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="index.php">RESTAURANT</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="index.php">Home</a></li>
        <li><a href="foodzone.php" class="hvr-underline-from-left">Food Zone</a></li>
        <li><a href="specialdeals.php" class="hvr-underline-from-left">Special Deals</a></li>
        <li><a href="member-index.php" class="hvr-underline-from-left">My Account</a></li>
        <li><a href="contactus.php" class="hvr-underline-from-left">Contact Us</a></li>
        <li><a href="aboutus.php" class="hvr-underline-from-left">AboutUS</a></li>
        <li><a href="team.php" class="hvr-underline-from-left">OurTeam</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li class="hvr-float-shadow">
          <a href="https://www.facebook.com/Restaurant-OS-551156428337035/" target="blank" data-toggle="tooltip" data-placement="top" title="Facebook">
            <img src="image/facebook_logo.png" style="width: 32px;height: 32px;" class="img-responsive">
          </a>
        </li>
        <li class="hvr-float-shadow">
          <a href="#" data-toggle="tooltip" data-placement="top" title="Twitter">
            <img src="image/twitter.png" style="width: 32px;height: 32px;" class="img-responsive">
          </a>
        </li>
        <li class="hvr-float-shadow">
          <a href="#" data-toggle="tooltip" data-placement="top" title="Google plus">
            <img src="image/google_plus.png" style="width: 32px;height: 32px;" class="img-responsive">
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>
</div>
</div>

<div class="content">
<div class="container">
  <div class="row" >
    <div class="col-sm-12">
      <div id="myCarousel" class="carousel slide" data-ride="carousel" style="position: relative; margin-top: -60px;">
    <!-- Indicators -->
          <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
          </ol>

          <!-- Wrapper for slides -->
          <div class="carousel-inner" role="listbox">
            <div class="item active">
              <img src="image/food/1.jpg" class="img-responsive">
            </div>

            <div class="item">
              <img src="image/food/2.jpg" class="img-responsive">
            </div>
          
            <div class="item">
              <img src="image/food/3.jpg" class="img-responsive">
            </div>
          </div>

          <!-- Left and right controls -->
          <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>
        </div>
    </div>
  </div>
  <h1>Gallery </h1>

</div>
</div>
<footer class="parallax-section" id="footer4">
  <div class="container" >
    <div class="row">
      <div class="col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.6s">
        <h4 class="heading-f">Contact Info:</h4>
        <div class="ph">
          <h6 class="heading-f1"><i class="fa fa-phone"></i>Phone:</h6>
          <h6 class="heading-f1"><i>+855 (0)15 5555 54 </i></h6>
          <h6 class="heading-f1"><i>+855 (0)12 5555 54</i></h6>
        </div>

        <div class="em">
          <h6 class="heading-f"><i class="fa fa-envelope"></i>Email:</h6>
          <h6 class="heading-f">restaurant_os@gmail.com</h6>
        </div>

        <div class="address">
          <h4 class="heading-f"><i class="fa fa-map-marker"></i> Our Location:</h4>
          <h6 class="heading-f"><i>No.136, Preah Sisowath Blvd, Phnom Penh, Cambodia</i></h6>
        </div>
      </div>
      
      <div class="col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.6s">
        <h4 class="heading-f">Open Hours</h4>
          <h6 class="heading-f"><i>Sunday <span>7:30 AM - 10:00 PM</span></i></h6>
          <h6 class="heading-f"><i>Mon-Fri <span>6:00 AM - 10:00 PM</span></i></h6>
          <h6 class="heading-f"><i>Saturday <span>6:30 AM - 10:00 PM</span></i></h6>
      </div>
      <div class="col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.6s">
        <h4 class="heading-f">Information</h4>
        <h6 class="heading-f"><i>Delivery Service</i></h6>
        <h6 class="heading-f"><i>News and Events</i></h6>
        <ul class="social-icon"; type="none">
          <li>
            <a href="https://www.facebook.com/Restaurant-OS-551156428337035/" target="blank" class="fa fa-facebook wow bounceIn" data-wow-delay="0.3s"></a>
          </li>
          <li><a href="#" class="fa fa-twitter wow bounceIn" data-wow-delay="0.6s"></a></li>
          <li><a href="#" class="fa fa-instagram wow bounceIn" data-wow-delay="0.9s"></a></li>
          <li><a href="#" class="fa fa-youtube wow bounceIn" data-wow-delay="0.11s"></a></li>
          <li><a href="#" class="fa fa-google  wow bounceIn" data-wow-delay="0.11s"></a></li>
        </ul><br>
        <h6 class="heading-f"><i><a href="admin/index.php" target="_blank">Administrator</a></i></h6>
        <h6 class="heading-f"><i>© 2010-2017 Restaurant OS. All rights reserved.</i></h6>
      </div>
    </div>
  </div>
</footer>
</body>
</html>