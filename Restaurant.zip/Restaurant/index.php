<?php
//checking connection and connecting to a database
require_once('connection/config.php');
//Connect to mysql server
    $link = @mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);
    if(!$link) {
        die('Failed to connect to server: ' . mysql_error());
    }
    
    //Select database
    $db = mysql_select_db(DB_DATABASE);
    if(!$db) {
        die("Unable to select database");
    }
    
//retrieve questions from the questions table
$questions=mysql_query("SELECT * FROM questions")
or die("Something is wrong ... \n" . mysql_error());
?>
<?php
//setting-up a remember me cookie
    if (isset($_POST['Submit'])){
        //setting up a remember me cookie
        if($_POST['remember']) {
            $year = time() + 31536000;
            setcookie('remember_me', $_POST['login'], $year);
        }
        else if(!$_POST['remember']) {
            if(isset($_COOKIE['remember_me'])) {
                $past = time() - 100;
                setcookie(remember_me, gone, $past);
            }
        }
    }
?>
<!DOCTYPE html>
<html>
<head>
 <title>Restaurant</title>
<meta charset="utf-8">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/jpg" href="image/a.jpg">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/nivo-lightbox.css">
    <link rel="stylesheet" type="text/css" href="css/default.css">
    <link rel="stylesheet" type="text/css" href="css/hover-min.css">
    <link rel="stylesheet" href="css/prettyPhoto.css" type="text/css" media="screen" charset="utf-8" />
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" type="text/css" href="font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
  <script type="text/javascript" src="js/jquery_1_11_2.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <script src="js/jquery.prettyPhoto.js" type="text/javascript" charset="utf-8"></script>
  <script language="JavaScript" src="validation/user.js"></script>
<!-- <link href="stylesheets/user_styles.css" rel="stylesheet" type="text/css"> -->
</head>
<body>
<div class="banner">
  <div class="container" >
    <div class="row">
      <div class="col-sm-12" style="margin: 5px 0px;"> 
        <a href="index.php"><img src="image/restaurant_logo.png" class="img-responsive"></a>
      </div>
    </div>
    </div>
<div> 
<nav class="navbar navbar-inverse"  data-spy="affix" data-offset-top="197">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="index.php">RESTAURANT</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="index.php">Home</a></li>
        <li><a href="foodzone.php" class="hvr-underline-from-left">Food Zone</a></li>
        <li><a href="specialdeals.php" class="hvr-underline-from-left">Special Deals</a></li>
        <li><a href="member-index.php" class="hvr-underline-from-left">My Account</a></li>
        <li><a href="contactus.php" class="hvr-underline-from-left">Contact Us</a></li>
        <li><a href="aboutus.php" class="hvr-underline-from-left">AboutUS</a></li>
        <li><a href="team.php" class="hvr-underline-from-left">OurTeam</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li class="hvr-float-shadow">
          <a href="https://www.facebook.com/Restaurant-OS-551156428337035/" target="blank" data-toggle="tooltip" data-placement="top" title="Facebook">
            <img src="image/facebook_logo.png" style="width: 32px;height: 32px;" class="img-responsive">
          </a>
        </li>
        <li class="hvr-float-shadow">
          <a href="#" data-toggle="tooltip" data-placement="top" title="Twitter">
            <img src="image/twitter.png" style="width: 32px;height: 32px;" class="img-responsive">
          </a>
        </li>
        <li class="hvr-float-shadow">
          <a href="#" data-toggle="tooltip" data-placement="top" title="Google plus">
            <img src="image/google_plus.png" style="width: 32px;height: 32px;" class="img-responsive">
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>
</div>
</div>

<div class="content">
<div class="container">
  <div class="row" >
    <div class="col-sm-12">
      <div id="myCarousel" class="carousel slide" data-ride="carousel" style="position: relative; margin-top: -60px;">
    <!-- Indicators -->
          <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
          </ol>

          <!-- Wrapper for slides -->
          <div class="carousel-inner" role="listbox">
            <div class="item active">
              <img src="image/food/1.jpg" class="img-responsive">
            </div>

            <div class="item">
              <img src="image/food/2.jpg" class="img-responsive">
            </div>
          
            <div class="item">
              <img src="image/food/3.jpg" class="img-responsive">
            </div>
          </div>

          <!-- Left and right controls -->
          <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>
        </div>
    </div>
  </div>
  <div class="row">
    <div class="col-sm-3">
      <div class="thumbnail block wow bounceInLeft">
        <a href="specialdeals.php" class="hvr-float-shadow">
          <img src="image/offer.png" alt="Lights" style="width:100%"> 
            <div class="caption">
            <button class="btn" type="submit" style="margin-left: 10%;margin-top: 5%; width: 80%;background-color: #c01d2e; border-color: none; color: white;">VIEW ALL</button>
          </div>
        </a>
      </div>
    </div>
    <div class="col-sm-3">
      <div class="thumbnail block wow bounceIn">
        <a href="#" class="hvr-float-shadow">
          <img src="image/save-up-to-25-percent.png" alt="Lights" style="width:100%">
          <div class="caption">
            <button class="btn" type="submit" style="margin-left: 10%;margin-top: 5%; width: 80%;background-color: #ae255f; border-color: none; color: white;">VIEW ALL</button>
          </div>
        </a>
      </div>
    </div>
    <div class="col-sm-3">
      <div class="thumbnail block wow bounceIn">
        <a href="#" class="hvr-float-shadow">
          <img src="image/drink.png" alt="Nature" style="width:100%">
          <div class="caption">
            <button class="btn" type="submit" style="margin-left: 10%;margin-top: 5%; width: 80%;background-color: #fd9d07; border-color: none; color: white;">VIEW ALL</button>
          </div>
        </a>
      </div>
    </div>
    <div class="col-sm-3">
      <div class="thumbnail block wow bounceInRight">
        <a href="#" class="hvr-float-shadow">
          <img src="image/fastfood.png" alt="Fjords" style="width:100%">
          <div class="caption">
            <button type="submit" class="btn" style="margin-left: 10%;margin-top: 5%; width: 80%;background-color: #ff4202; border-color: none; color: white;">VIEW ALL</button>
          </div>
        </a>
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col-sm-8 wow fadeInDown">
      <p style="color: #361714; text-align: justify;"><b><h2>WELCOME to OS Restaurant</h2></b> <br>
        <h5>A true taste of Cambodia in cuisine and décor, OS serves Cambodian food that ranges from almost forgotten recipes from the provinces to contemporary creative Cambodian cuisine.<br><br>
      It is set in a beautiful colonial building whose wooden carvings, tables, chairs and unique lights were all hand made in Cambodia. The silk goods and cushions adorning Romdeng were made by our students in sewing training at Mith Samlanh and its walls are hung with beautiful paintings produced by young people from the art classes there. All of this plus a pool, free WIFI, a family area and a gift shop mean a visit to Romdeng is a must.
      Check out our mouth-watering menu. Take a break in our shop. Find our cookbook.</h5></p>
      </div>
      <div class="col-sm-4 wow fadeInDown">
        <p style="color: #361714;"><b><h1>MOST POPULAR</h1></b>
          <ul type="none" style="margin-left: 25%;">
            <li>
              <b>SOMLOR Korko</b>
            </li>
            <li>
              <b>ORANGE Juice</b>
            </li>
            <li>
              <b>PIZZA KIKI</b>
            </li>
            <li>
                <button type="submit" class="btn hvr-bounce-to-right" style="margin-top: 5%; background-color: #341713; border-color: none; color: white;"><a href="#" data-toggle="tooltip" data-placement="buttom" title="PIZZA">More...</a></button>
            </li>
          </ul>
        </p>
      </div>
    </div>

  <div class="row">
    <div class="col-md-4">

    </div>
  </div>
  <div class="row wow bounceIn">
    <div class="col-md-4">
      <div class="panel panel-default" style="border-radius: 15px;">
      <div class="panel-heading" style=" border-top-right-radius: 15px;border-top-left-radius: 15px;">FOLLOW US!!</div>
      <div class="panel-body">
        <div class="caption" style="width: 100%;">
          <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FRestaurant-OS-551156428337035%2F&tabs&width=340&height=214&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" height="200" style="border:none;overflow:hidden; width: 100%" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
          </div>
       </div>
    </div>
    </div>
    <div class="col-md-4">
    <div class="panel panel-default" style="border-radius: 15px;">
      <div class="panel-heading" style=" border-top-right-radius: 15px;border-top-left-radius: 15px;">LOCATION</div>
      <div class="panel-body">
        <div class="caption" style="width: 100%;">
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3908.7402165031244!2d104.89618211500866!3d11.570471791785701!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3109517388680e15%3A0x63057e6682968f5!2sInstitute+of+Technology+of+Cambodia+(ITC)!5e0!3m2!1sen!2skh!4v1487775873302"  height="200" width="100%" frameborder="0" style="border:0;" allowfullscreen></iframe>
          </div>
       </div>
    </div>
    </div>
    <div class="col-md-4">
    <div class="panel panel-default" style="border-radius: 15px;">
      <div class="panel-heading" style=" border-top-right-radius: 15px;border-top-left-radius: 15px;">OPENING HOURS</div>
      <div class="panel-body">
        <div class="caption" style="width: 100%;">
          <p>Monday - Friday <span><h3>6:00 AM - 10:00 PM</h3></span></p>
          <p>Saturday <span><h3>6:30 AM - 10:00 PM</h3></span></p>
          <p>Sunday <span><h3>7:30 AM - 10:00 PM</h3></span></p>       
              
          </div>
       </div>
    </div>
    </div>
  </div>
</div>
</div>
</div>
</div>

<footer class="parallax-section" id="footer4">
  <div class="container" >
    <div class="row">
      <div class="col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.6s">
        <h4 class="heading-f">Contact Info:</h4>
        <div class="ph">
          <h6 class="heading-f1"><i class="fa fa-phone"></i>Phone:</h6>
          <h6 class="heading-f1"><i>+855 (0)15 5555 54 </i></h6>
          <h6 class="heading-f1"><i>+855 (0)12 5555 54</i></h6>
        </div>

        <div class="em">
          <h6 class="heading-f"><i class="fa fa-envelope"></i>Email:</h6>
          <h6 class="heading-f">restaurant_os@gmail.com</h6>
        </div>

        <div class="address">
          <h4 class="heading-f"><i class="fa fa-map-marker"></i> Our Location:</h4>
          <h6 class="heading-f"><i>No.136, Preah Sisowath Blvd, Phnom Penh, Cambodia</i></h6>
        </div>
      </div>
      
      <div class="col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.6s">
        <h4 class="heading-f">Open Hours</h4>
          <h6 class="heading-f"><i>Sunday <span>7:30 AM - 10:00 PM</span></i></h6>
          <h6 class="heading-f"><i>Mon-Fri <span>6:00 AM - 10:00 PM</span></i></h6>
          <h6 class="heading-f"><i>Saturday <span>6:30 AM - 10:00 PM</span></i></h6>
      </div>
      <div class="col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.6s">
        <h4 class="heading-f">Information</h4>
        <h6 class="heading-f"><i>Delivery Service</i></h6>
        <h6 class="heading-f"><i>News and Events</i></h6>
        <ul class="social-icon"; type="none">
          <li>
            <a href="https://www.facebook.com/Restaurant-OS-551156428337035/" target="blank" class="fa fa-facebook wow bounceIn" data-wow-delay="0.3s"></a>
          </li>
          <li><a href="#" class="fa fa-twitter wow bounceIn" data-wow-delay="0.6s"></a></li>
          <li><a href="#" class="fa fa-instagram wow bounceIn" data-wow-delay="0.9s"></a></li>
          <li><a href="#" class="fa fa-youtube wow bounceIn" data-wow-delay="0.11s"></a></li>
          <li><a href="#" class="fa fa-google  wow bounceIn" data-wow-delay="0.11s"></a></li>
        </ul><br>
        <h6 class="heading-f"><i><a href="admin/index.php" target="_blank">Administrator</a></i></h6>
        <h6 class="heading-f"><i>© 2010-2017 Restaurant OS. All rights reserved.</i></h6>
      </div>
    </div>
  </div>
</footer>

<script type="text/javascript" charset="utf-8">
$(document).ready(function(){
  $("a[rel^='prettyPhoto']").prettyPhoto();
});
</script>
 <script src="js/wow.min.js"></script>
<script>
    new WOW().init();
</script>

</body>
</html>
